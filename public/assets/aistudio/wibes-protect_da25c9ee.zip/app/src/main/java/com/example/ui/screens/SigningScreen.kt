package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.KeystoreConfig
import com.example.model.KeystoreMode
import com.example.signing.SigningEngine
import com.example.ui.components.CyberCard
import com.example.ui.components.CyberGradientButton
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SuccessGreen

@Composable
fun SigningScreen(
    config: KeystoreConfig,
    onUpdateConfig: (KeystoreConfig) -> Unit,
    onBrowseKeystoreFile: () -> Unit
) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf(config.mode) }
    var alias by remember { mutableStateOf(config.keyAlias) }
    var password by remember { mutableStateOf(config.keystorePassword) }
    var ownerName by remember { mutableStateOf(config.ownerName) }
    var org by remember { mutableStateOf(config.organization) }
    var validity by remember { mutableStateOf(config.validityYears.toString()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("signing_screen")
    ) {
        // Signing Engine Banner
        CyberCard(glowColor = PrimaryPurple.copy(alpha = 0.3f)) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(PrimaryPurple.copy(alpha = 0.25f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = null,
                        tint = ElectricViolet,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "APK Signing Manager",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Dual V1 (JAR) + V2 (APK Scheme) Digital Signatures",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Mode Selector Card
        CyberCard {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "KEYSTORE CONFIGURATION MODE",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricViolet,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Auto Generate Option
                ModeRow(
                    title = "Automatic Keystore Generation",
                    subtitle = "Generates and maintains a dedicated 2048-bit RSA key pair automatically.",
                    selected = mode == KeystoreMode.AUTO_GENERATE,
                    onClick = {
                        mode = KeystoreMode.AUTO_GENERATE
                        onUpdateConfig(config.copy(mode = KeystoreMode.AUTO_GENERATE))
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Custom New Keystore Option
                ModeRow(
                    title = "Option A: Generate Custom Keystore",
                    subtitle = "Define custom alias, password, validity, and certificate owner credentials.",
                    selected = mode == KeystoreMode.CUSTOM_NEW,
                    onClick = {
                        mode = KeystoreMode.CUSTOM_NEW
                        onUpdateConfig(config.copy(mode = KeystoreMode.CUSTOM_NEW))
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Import Existing Option
                ModeRow(
                    title = "Option B: Import Existing Keystore",
                    subtitle = "Sign using your existing production .jks, .keystore, or .p12 certificate.",
                    selected = mode == KeystoreMode.IMPORT_EXISTING,
                    onClick = {
                        mode = KeystoreMode.IMPORT_EXISTING
                        onUpdateConfig(config.copy(mode = KeystoreMode.IMPORT_EXISTING))
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Parameter Configuration Card
        if (mode == KeystoreMode.CUSTOM_NEW) {
            CyberCard(glowColor = ElectricViolet.copy(alpha = 0.25f)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "CUSTOM CERTIFICATE PARAMETERS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = ElectricViolet
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    StyledTextField(value = alias, onValueChange = { alias = it }, label = "Key Alias")
                    Spacer(modifier = Modifier.height(8.dp))
                    StyledTextField(value = password, onValueChange = { password = it }, label = "Keystore Password")
                    Spacer(modifier = Modifier.height(8.dp))
                    StyledTextField(value = ownerName, onValueChange = { ownerName = it }, label = "Certificate Owner (CN)")
                    Spacer(modifier = Modifier.height(8.dp))
                    StyledTextField(value = org, onValueChange = { org = it }, label = "Organization (O)")
                    Spacer(modifier = Modifier.height(8.dp))
                    StyledTextField(value = validity, onValueChange = { validity = it }, label = "Validity (Years)")

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val years = validity.toIntOrNull() ?: 25
                            onUpdateConfig(
                                config.copy(
                                    mode = KeystoreMode.CUSTOM_NEW,
                                    keyAlias = alias,
                                    keystorePassword = password,
                                    keyPassword = password,
                                    ownerName = ownerName,
                                    organization = org,
                                    validityYears = years
                                )
                            )
                            Toast.makeText(context, "Saved Custom Keystore Settings", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple)
                    ) {
                        Text("Apply Keystore Settings", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else if (mode == KeystoreMode.IMPORT_EXISTING) {
            CyberCard(glowColor = CyberCyan.copy(alpha = 0.25f)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "IMPORT PRODUCTION KEYSTORE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyan
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (config.keystorePath.isNotEmpty()) "Selected: ${config.keystorePath}" else "No keystore file selected (.jks, .keystore, .p12)",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = onBrowseKeystoreFile,
                        modifier = Modifier.fillMaxWidth().height(46.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Browse Keystore File")
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    StyledTextField(value = alias, onValueChange = { alias = it }, label = "Key Alias")
                    Spacer(modifier = Modifier.height(8.dp))
                    StyledTextField(value = password, onValueChange = { password = it }, label = "Keystore Password")

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            onUpdateConfig(
                                config.copy(
                                    mode = KeystoreMode.IMPORT_EXISTING,
                                    keyAlias = alias,
                                    keystorePassword = password,
                                    keyPassword = password
                                )
                            )
                            Toast.makeText(context, "Applied Import Settings", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple)
                    ) {
                        Text("Save & Apply Keystore", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            // Auto Mode Info
            CyberCard(glowColor = SuccessGreen.copy(alpha = 0.2f)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Zero-Configuration Automatic Signing", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "WIBES PROTECT will automatically generate and inject compliant cryptographic certificates for every rebuilt APK. Both V1 and V2 signature schemes are verified locally on-device.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 17.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Security Notice Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF0D0E17))
                .padding(12.dp)
        ) {
            Text(
                text = "⚠️ Important Signing Policy:\nNever transmit private keys or passwords over the network. All cryptographic operations happen exclusively in-memory on your Android device. Note that changing the signing certificate prevents normal updates over an existing installation signed with another certificate.",
                fontSize = 11.sp,
                color = Color(0xFFA5A9C5),
                lineHeight = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun ModeRow(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) PrimaryPurple.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            onClick = onClick,
            colors = RadioButtonDefaults.colors(selectedColor = ElectricViolet)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Text(text = subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun StyledTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, fontSize = 12.sp) },
        modifier = Modifier.fillMaxWidth().height(56.dp),
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = ElectricViolet,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline
        ),
        singleLine = true
    )
}
