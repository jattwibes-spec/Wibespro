package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// WIBES PROTECT Brand Colors
val PrimaryPurple = Color(0xFF6849B5)
val SecondaryPurple = Color(0xFF8061D2)
val ElectricViolet = Color(0xFF9D6BFF)
val ElectricVioletBright = Color(0xFFB58EFF)
val CyberCyan = Color(0xFF00E5FF)
val NeonAccent = Color(0xFF00F5D4)

// Background & Surfaces
val BackgroundLight = Color(0xFFF5F4FA)
val BackgroundDark = Color(0xFF10111C)
val SurfaceDark = Color(0xFF161726)
val CardLight = Color(0xFFFFFFFF)
val CardDark = Color(0xFF1C1D2B)
val CardDarkElevated = Color(0xFF24263A)
val CardBorderDark = Color(0xFF2D2F48)
val CardBorderGlow = Color(0xFF6849B5)

// Status Colors
val SuccessGreen = Color(0xFF32B768)
val WarningOrange = Color(0xFFFFAA42)
val ErrorRed = Color(0xFFEF5350)
val InfoBlue = Color(0xFF3897F0)

// Text Colors
val TextPrimaryDark = Color(0xFFF2F1FA)
val TextSecondaryDark = Color(0xFFA5A6BC)
val TextMutedDark = Color(0xFF6E7191)

val TextPrimaryLight = Color(0xFF161724)
val TextSecondaryLight = Color(0xFF5A5C75)
val TextMutedLight = Color(0xFF8E90A6)
