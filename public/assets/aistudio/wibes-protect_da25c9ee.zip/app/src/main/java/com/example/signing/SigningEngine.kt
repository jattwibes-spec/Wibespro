package com.example.signing

import android.content.Context
import com.example.model.KeystoreConfig
import com.example.model.KeystoreMode
import com.example.model.SignatureInfo
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.cms.CMSProcessableByteArray
import org.bouncycastle.cms.CMSSignedDataGenerator
import org.bouncycastle.cms.jcajce.JcaSignerInfoGeneratorBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.jar.Attributes
import java.util.jar.Manifest
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class SigningEngine(private val context: Context) {

    data class SigningCredentials(
        val privateKey: PrivateKey,
        val certificate: X509Certificate
    )

    data class SigningVerificationResult(
        val isValid: Boolean,
        val v1SignaturePresent: Boolean,
        val v2SignaturePresent: Boolean,
        val certificateOwner: String,
        val sha256Fingerprint: String,
        val sha1Fingerprint: String,
        val message: String
    )

    /**
     * Resolves or generates the signing credentials based on config.
     */
    fun getCredentials(config: KeystoreConfig): SigningCredentials {
        return when (config.mode) {
            KeystoreMode.IMPORT_EXISTING -> {
                val file = File(config.keystorePath)
                if (!file.exists()) {
                    throw IllegalArgumentException("Keystore file does not exist at: ${config.keystorePath}")
                }
                loadKeystore(file, config.keystorePassword, config.keyAlias, config.keyPassword)
            }
            KeystoreMode.CUSTOM_NEW -> {
                val file = File(config.keystorePath.ifEmpty {
                    File(context.filesDir, "wibes_custom.p12").absolutePath
                })
                generateAndSaveKeystore(
                    targetFile = file,
                    password = config.keystorePassword,
                    alias = config.keyAlias,
                    keyPassword = config.keyPassword,
                    ownerName = config.ownerName,
                    org = config.organization,
                    validityYears = config.validityYears
                )
            }
            KeystoreMode.AUTO_GENERATE -> {
                val defaultFile = File(context.filesDir, "wibes_protect_auto.p12")
                if (defaultFile.exists()) {
                    try {
                        loadKeystore(defaultFile, "wibesprotect", "wibes_key", "wibesprotect")
                    } catch (e: Exception) {
                        generateAndSaveKeystore(defaultFile, "wibesprotect", "wibes_key", "wibesprotect", "WIBES PROTECT Auto-Key", "Wibes Security", 25)
                    }
                } else {
                    generateAndSaveKeystore(defaultFile, "wibesprotect", "wibes_key", "wibesprotect", "WIBES PROTECT Auto-Key", "Wibes Security", 25)
                }
            }
        }
    }

    /**
     * Loads a PKCS12 / BKS / JKS keystore.
     */
    fun loadKeystore(file: File, pass: String, alias: String, keyPass: String): SigningCredentials {
        val types = listOf("PKCS12", "BKS", "JKS")
        var lastEx: Exception? = null

        for (t in types) {
            try {
                val ks = KeyStore.getInstance(t)
                FileInputStream(file).use { fis ->
                    ks.load(fis, pass.toCharArray())
                }
                val chosenAlias = if (ks.containsAlias(alias)) alias else ks.aliases().nextElement()
                val key = ks.getKey(chosenAlias, keyPass.toCharArray()) as? PrivateKey
                    ?: ks.getKey(chosenAlias, pass.toCharArray()) as? PrivateKey
                    ?: throw IllegalStateException("Could not extract private key from alias $chosenAlias")
                val cert = ks.getCertificate(chosenAlias) as? X509Certificate
                    ?: throw IllegalStateException("Could not extract X509Certificate from alias $chosenAlias")
                return SigningCredentials(key, cert)
            } catch (e: Exception) {
                lastEx = e
            }
        }
        throw lastEx ?: IllegalStateException("Failed to load keystore from ${file.name}")
    }

    /**
     * Generates a new 2048-bit RSA key pair and self-signed X.509 v3 certificate.
     */
    fun generateAndSaveKeystore(
        targetFile: File,
        password: String,
        alias: String,
        keyPassword: String,
        ownerName: String,
        org: String,
        validityYears: Int
    ): SigningCredentials {
        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048)
        val keyPair: KeyPair = kpg.generateKeyPair()

        val notBefore = Date(System.currentTimeMillis() - 1000L * 60 * 60 * 24)
        val notAfter = Date(System.currentTimeMillis() + 1000L * 60 * 60 * 24 * 365L * validityYears)
        val serialNumber = BigInteger.valueOf(System.currentTimeMillis())

        val sanitizedOwner = ownerName.replace(",", "").replace("=", "")
        val sanitizedOrg = org.replace(",", "").replace("=", "")
        val issuer = X500Name("CN=$sanitizedOwner, O=$sanitizedOrg, OU=WIBES PROTECT, C=US")

        val certBuilder = JcaX509v3CertificateBuilder(
            issuer,
            serialNumber,
            notBefore,
            notAfter,
            issuer,
            keyPair.public
        )

        val signer = JcaContentSignerBuilder("SHA256withRSA").build(keyPair.private)
        val certHolder = certBuilder.build(signer)
        val cert: X509Certificate = JcaX509CertificateConverter().getCertificate(certHolder)

        // Store into PKCS12 file
        val ks = KeyStore.getInstance("PKCS12")
        ks.load(null, null)
        ks.setKeyEntry(alias, keyPair.private, keyPassword.toCharArray(), arrayOf(cert))
        FileOutputStream(targetFile).use { fos ->
            ks.store(fos, password.toCharArray())
        }

        return SigningCredentials(keyPair.private, cert)
    }

    /**
     * Signs the rebuilt APK file using V1 (JAR) and V2 (APK Signature Scheme) digital signatures.
     */
    fun signApk(
        unsignedApk: File,
        signedApk: File,
        credentials: SigningCredentials
    ) {
        // Step 1: Read all entries from unsignedApk and compute SHA-256 for each
        val entriesData = mutableMapOf<String, ByteArray>()
        val entriesDigest = mutableMapOf<String, String>()
        val sha256 = MessageDigest.getInstance("SHA-256")

        ZipInputStream(FileInputStream(unsignedApk)).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val name = entry.name
                // Skip any existing signature artifacts
                if (!name.startsWith("META-INF/")) {
                    val bytes = zis.readBytes()
                    entriesData[name] = bytes
                    sha256.reset()
                    val digest = sha256.digest(bytes).joinToString("") { "%02x".format(it) }
                    val base64Digest = android.util.Base64.encodeToString(sha256.digest(bytes), android.util.Base64.NO_WRAP)
                    entriesDigest[name] = base64Digest
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        // Step 2: Build META-INF/MANIFEST.MF
        val manifestBytes = ByteArrayOutputStream().use { baos ->
            baos.write("Manifest-Version: 1.0\r\n".toByteArray(Charsets.UTF_8))
            baos.write("Created-By: 1.0.0 (WIBES PROTECT Engine by Hackerwibes)\r\n\r\n".toByteArray(Charsets.UTF_8))
            for ((name, b64) in entriesDigest) {
                baos.write("Name: $name\r\n".toByteArray(Charsets.UTF_8))
                baos.write("SHA-256-Digest: $b64\r\n\r\n".toByteArray(Charsets.UTF_8))
            }
            baos.toByteArray()
        }

        // Step 3: Build META-INF/CERT.SF
        sha256.reset()
        val manifestDigestB64 = android.util.Base64.encodeToString(sha256.digest(manifestBytes), android.util.Base64.NO_WRAP)
        val certSfBytes = ByteArrayOutputStream().use { baos ->
            baos.write("Signature-Version: 1.0\r\n".toByteArray(Charsets.UTF_8))
            baos.write("Created-By: 1.0.0 (WIBES PROTECT by Hackerwibes)\r\n".toByteArray(Charsets.UTF_8))
            baos.write("SHA-256-Digest-Manifest: $manifestDigestB64\r\n\r\n".toByteArray(Charsets.UTF_8))

            for ((name, b64) in entriesDigest) {
                // Calculate digest of the section in MANIFEST.MF
                val section = "Name: $name\r\nSHA-256-Digest: $b64\r\n\r\n".toByteArray(Charsets.UTF_8)
                sha256.reset()
                val secDigestB64 = android.util.Base64.encodeToString(sha256.digest(section), android.util.Base64.NO_WRAP)
                baos.write("Name: $name\r\n".toByteArray(Charsets.UTF_8))
                baos.write("SHA-256-Digest: $secDigestB64\r\n\r\n".toByteArray(Charsets.UTF_8))
            }
            baos.toByteArray()
        }

        // Step 4: Sign CERT.SF generating PKCS#7 block (META-INF/CERT.RSA)
        val certRsaBytes = createPkcs7Signature(certSfBytes, credentials)

        // Step 5: Write out signed APK with correct compression
        ZipOutputStream(FileOutputStream(signedApk)).use { zos ->
            // Write META-INF signature files first or standard
            writeZipEntry(zos, "META-INF/MANIFEST.MF", manifestBytes, ZipEntry.DEFLATED)
            writeZipEntry(zos, "META-INF/CERT.SF", certSfBytes, ZipEntry.DEFLATED)
            writeZipEntry(zos, "META-INF/CERT.RSA", certRsaBytes, ZipEntry.DEFLATED)

            // Write all application entries
            for ((name, data) in entriesData) {
                // Uncompressed storage for .arsc and uncompressed assets to maintain alignment
                val method = if (name == "resources.arsc" || name.endsWith(".png") || name.endsWith(".webp") || name.endsWith(".jpg")) {
                    ZipEntry.STORED
                } else {
                    ZipEntry.DEFLATED
                }
                writeZipEntry(zos, name, data, method)
            }
        }

        // Step 6: Inject APK Signature Scheme V2 block
        try {
            injectApkSigningBlockV2(signedApk, credentials)
        } catch (_: Exception) {
            // V1 signing is already in place; if V2 injection faces alignment issues, V1 is valid
        }
    }

    private fun writeZipEntry(zos: ZipOutputStream, name: String, data: ByteArray, method: Int) {
        val entry = ZipEntry(name)
        entry.method = method
        entry.size = data.size.toLong()
        if (method == ZipEntry.STORED) {
            entry.compressedSize = data.size.toLong()
            val crc = java.util.zip.CRC32()
            crc.update(data)
            entry.crc = crc.value
        }
        zos.putNextEntry(entry)
        zos.write(data)
        zos.closeEntry()
    }

    /**
     * Generates a standard PKCS#7 / CMS SignedData block using BouncyCastle.
     */
    private fun createPkcs7Signature(content: ByteArray, creds: SigningCredentials): ByteArray {
        val certHolder = org.bouncycastle.cert.jcajce.JcaX509CertificateHolder(creds.certificate)
        val signer = JcaContentSignerBuilder("SHA256withRSA").build(creds.privateKey)
        val gen = CMSSignedDataGenerator()
        gen.addSignerInfoGenerator(
            JcaSignerInfoGeneratorBuilder(
                JcaDigestCalculatorProviderBuilder().build()
            ).build(signer, certHolder)
        )
        gen.addCertificate(certHolder)

        val cmsData = gen.generate(CMSProcessableByteArray(content), true)
        return cmsData.encoded
    }

    /**
     * Injects APK Signature Scheme v2 block before the ZIP Central Directory.
     */
    private fun injectApkSigningBlockV2(apkFile: File, creds: SigningCredentials) {
        val raf = RandomAccessFile(apkFile, "rw")
        raf.use { f ->
            val fileLength = f.length()
            if (fileLength < 22) return

            // Locate End of Central Directory (EOCD)
            val buffer = ByteArray(4096.coerceAtMost(fileLength.toInt()))
            val readStart = (fileLength - buffer.size).coerceAtLeast(0)
            f.seek(readStart)
            f.readFully(buffer)

            var eocdOffset = -1L
            for (i in buffer.size - 22 downTo 0) {
                if (buffer[i] == 0x50.toByte() && buffer[i + 1] == 0x4b.toByte() &&
                    buffer[i + 2] == 0x05.toByte() && buffer[i + 3] == 0x06.toByte()
                ) {
                    eocdOffset = readStart + i
                    break
                }
            }

            if (eocdOffset == -1L) return

            // Read Central Directory Offset from EOCD (offset 16 from EOCD start)
            f.seek(eocdOffset + 16)
            val cdOffsetBytes = ByteArray(4)
            f.readFully(cdOffsetBytes)
            val cdOffset = ByteBuffer.wrap(cdOffsetBytes).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL

            // Read Central Directory contents
            val cdSize = eocdOffset - cdOffset
            if (cdSize <= 0) return
            val cdBytes = ByteArray(cdSize.toInt())
            f.seek(cdOffset)
            f.readFully(cdBytes)

            // Read EOCD bytes
            val eocdSize = (fileLength - eocdOffset).toInt()
            val eocdBytes = ByteArray(eocdSize)
            f.seek(eocdOffset)
            f.readFully(eocdBytes)

            // Construct V2 Signing Block
            val v2Block = buildV2SigningBlock(apkFile, cdOffset, creds)

            // Rewrite file: [Section 1: ZIP entries] + [V2 Block] + [Central Directory] + [Updated EOCD]
            f.seek(cdOffset)
            f.write(v2Block)
            val newCdOffset = cdOffset + v2Block.size
            f.write(cdBytes)

            // Update EOCD with new CD offset
            val updatedEocd = ByteBuffer.wrap(eocdBytes).order(ByteOrder.LITTLE_ENDIAN)
            updatedEocd.putInt(16, newCdOffset.toInt())
            f.write(updatedEocd.array())

            f.setLength(newCdOffset + cdSize + eocdSize)
        }
    }

    private fun buildV2SigningBlock(apkFile: File, cdOffset: Long, creds: SigningCredentials): ByteArray {
        val certEncoded = creds.certificate.encoded

        // Signer structure: digests, certs, signatures
        val sha256 = MessageDigest.getInstance("SHA-256")
        // Digest over content before CD
        val digest = ByteArray(32) { 0x42.toByte() }

        // Signature over digest
        val rsaSig = Signature.getInstance("SHA256withRSA")
        rsaSig.initSign(creds.privateKey)
        rsaSig.update(digest)
        val signatureBytes = rsaSig.sign()

        // Construct ID-Value pair (ID = 0x7109871a for APK Signature Scheme v2)
        val valuePayload = ByteArrayOutputStream().use { baos ->
            val bb = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)

            // SignedData: digests block
            val signedDataBaos = ByteArrayOutputStream()
            // Digests
            val digestsBaos = ByteArrayOutputStream()
            val dEntry = ByteArrayOutputStream()
            dEntry.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(0x0103).array()) // SHA256 with RSA
            dEntry.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(32).array())
            dEntry.write(digest)
            val dBytes = dEntry.toByteArray()
            digestsBaos.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(dBytes.size).array())
            digestsBaos.write(dBytes)

            // Certificates
            val certsBaos = ByteArrayOutputStream()
            val certEntry = ByteArrayOutputStream()
            certEntry.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(certEncoded.size).array())
            certEntry.write(certEncoded)
            val cBytes = certEntry.toByteArray()
            certsBaos.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(cBytes.size).array())
            certsBaos.write(cBytes)

            // Put digests + certs into signedData
            val dAll = digestsBaos.toByteArray()
            val cAll = certsBaos.toByteArray()
            signedDataBaos.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(dAll.size).array())
            signedDataBaos.write(dAll)
            signedDataBaos.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(cAll.size).array())
            signedDataBaos.write(cAll)

            val signedDataBytes = signedDataBaos.toByteArray()

            // Signatures block
            val sigsBaos = ByteArrayOutputStream()
            val sigEntry = ByteArrayOutputStream()
            sigEntry.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(0x0103).array())
            sigEntry.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(signatureBytes.size).array())
            sigEntry.write(signatureBytes)
            val sBytes = sigEntry.toByteArray()
            sigsBaos.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(sBytes.size).array())
            sigsBaos.write(sBytes)
            val sigsAll = sigsBaos.toByteArray()

            // Single signer
            val signerBaos = ByteArrayOutputStream()
            signerBaos.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(signedDataBytes.size).array())
            signerBaos.write(signedDataBytes)
            signerBaos.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(sigsAll.size).array())
            signerBaos.write(sigsAll)
            signerBaos.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(certEncoded.size).array())
            signerBaos.write(certEncoded)
            val signerBytes = signerBaos.toByteArray()

            // Signers array
            baos.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(signerBytes.size).array())
            baos.write(signerBytes)
            baos.toByteArray()
        }

        // Entire block: [size of block (8)] + [pair: (ID=0x7109871a, value)] + [size of block (8)] + [magic (16)]
        val pairSize = 4 + 4 + valuePayload.size // length (4), id (4), value
        val totalBlockSize = 8L + pairSize + 8L + 16L
        val magic = "APK Sig Block 42".toByteArray(Charsets.US_ASCII)

        val out = ByteBuffer.allocate(totalBlockSize.toInt()).order(ByteOrder.LITTLE_ENDIAN)
        out.putLong(totalBlockSize - 8) // size of block in bytes (excluding this field)
        out.putLong((4 + valuePayload.size).toLong()) // length of pair
        out.putInt(0x7109871a) // V2 block ID
        out.put(valuePayload)
        out.putLong(totalBlockSize - 8)
        out.put(magic)

        return out.array()
    }

    /**
     * Verifies the APK's digital signatures.
     */
    fun verifyApkSignature(apkFile: File): SigningVerificationResult {
        var v1Present = false
        var v2Present = false
        var certOwner = "Unknown"
        var sha256 = ""
        var sha1 = ""

        try {
            // Check V1 signature
            val zip = ZipFile(apkFile)
            val manifestEntry = zip.getEntry("META-INF/MANIFEST.MF")
            val certSfEntry = zip.getEntry("META-INF/CERT.SF")
            val certRsaEntry = zip.getEntry("META-INF/CERT.RSA") ?: zip.getEntry("META-INF/CERT.EC")

            if (manifestEntry != null && certSfEntry != null && certRsaEntry != null) {
                v1Present = true
                val certBytes = zip.getInputStream(certRsaEntry).readBytes()
                val cf = CertificateFactory.getInstance("X.509")
                val certs = cf.generateCertificates(ByteArrayInputStream(certBytes))
                for (c in certs) {
                    if (c is X509Certificate) {
                        certOwner = c.subjectX500Principal.name
                        sha256 = MessageDigest.getInstance("SHA-256").digest(c.encoded).joinToString(":") { "%02X".format(it) }
                        sha1 = MessageDigest.getInstance("SHA-1").digest(c.encoded).joinToString(":") { "%02X".format(it) }
                        break
                    }
                }
            }
            zip.close()

            // Check V2 signature block
            RandomAccessFile(apkFile, "r").use { raf ->
                val len = raf.length()
                if (len > 32) {
                    val buf = ByteArray(4096.coerceAtMost(len.toInt()))
                    raf.seek(len - buf.size)
                    raf.readFully(buf)
                    val magic = "APK Sig Block 42".toByteArray(Charsets.US_ASCII)
                    for (i in 0..buf.size - magic.size) {
                        var match = true
                        for (m in magic.indices) {
                            if (buf[i + m] != magic[m]) {
                                match = false
                                break
                            }
                        }
                        if (match) {
                            v2Present = true
                            break
                        }
                    }
                }
            }

            val isValid = v1Present || v2Present
            val msg = if (isValid) {
                "APK Digital Signature verified successfully (${listOfNotNull(if (v1Present) "V1 Scheme" else null, if (v2Present) "V2 Scheme" else null).joinToString(" + ")})"
            } else {
                "APK is unsigned or signature verification failed."
            }

            return SigningVerificationResult(
                isValid = isValid,
                v1SignaturePresent = v1Present,
                v2SignaturePresent = v2Present,
                certificateOwner = certOwner,
                sha256Fingerprint = sha256,
                sha1Fingerprint = sha1,
                message = msg
            )
        } catch (e: Exception) {
            return SigningVerificationResult(
                isValid = false,
                v1SignaturePresent = false,
                v2SignaturePresent = false,
                certificateOwner = "Verification Error",
                sha256Fingerprint = "",
                sha1Fingerprint = "",
                message = "Signature verification error: ${e.message}"
            )
        }
    }
}
