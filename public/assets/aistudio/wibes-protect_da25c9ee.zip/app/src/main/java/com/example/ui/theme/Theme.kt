package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ElectricViolet,
    onPrimary = Color.White,
    primaryContainer = PrimaryPurple,
    onPrimaryContainer = Color.White,
    secondary = SecondaryPurple,
    onSecondary = Color.White,
    secondaryContainer = CardDarkElevated,
    onSecondaryContainer = ElectricVioletBright,
    tertiary = CyberCyan,
    onTertiary = BackgroundDark,
    background = BackgroundDark,
    onBackground = TextPrimaryDark,
    surface = SurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = CardDark,
    onSurfaceVariant = TextSecondaryDark,
    surfaceTint = PrimaryPurple,
    outline = CardBorderDark,
    outlineVariant = CardBorderGlow.copy(alpha = 0.35f),
    error = ErrorRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = PrimaryPurple,
    onPrimary = Color.White,
    primaryContainer = SecondaryPurple.copy(alpha = 0.15f),
    onPrimaryContainer = PrimaryPurple,
    secondary = SecondaryPurple,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEDE9FE),
    onSecondaryContainer = PrimaryPurple,
    tertiary = PrimaryPurple,
    onTertiary = Color.White,
    background = BackgroundLight,
    onBackground = TextPrimaryLight,
    surface = CardLight,
    onSurface = TextPrimaryLight,
    surfaceVariant = Color(0xFFEBE9F5),
    onSurfaceVariant = TextSecondaryLight,
    surfaceTint = PrimaryPurple,
    outline = Color(0xFFD6D4E5),
    outlineVariant = PrimaryPurple.copy(alpha = 0.2f),
    error = ErrorRed,
    onError = Color.White
)

@Composable
fun WibesProtectTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
