package com.example

import com.example.engine.DexTransformer
import com.example.engine.ModulesRegistry
import com.example.model.ProtectionCategory
import com.example.model.ProtectionProfile
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.util.Date
import java.util.zip.Adler32

class ProtectionEngineTest {

    @Test
    fun testModulesRegistryComplete() {
        val modules = ModulesRegistry.getAllModules()
        assertEquals("Must have 40 protection modules", 40, modules.size)

        val codeMods = modules.filter { it.category == ProtectionCategory.CODE_OBFUSCATION }
        val dexMods = modules.filter { it.category == ProtectionCategory.DEX_PROTECTION }
        val resMods = modules.filter { it.category == ProtectionCategory.RESOURCE_PROTECTION }
        val hardMods = modules.filter { it.category == ProtectionCategory.APP_HARDENING }

        assertEquals(15, codeMods.size)
        assertEquals(8, dexMods.size)
        assertEquals(7, resMods.size)
        assertEquals(10, hardMods.size)

        // Check profile module allocation
        val maxProfileMods = ModulesRegistry.getModulesForProfile(ProtectionProfile.MAXIMUM)
        assertTrue(maxProfileMods.all { it.isEnabled })

        val basicProfileMods = ModulesRegistry.getModulesForProfile(ProtectionProfile.BASIC)
        assertTrue(basicProfileMods.count { it.isEnabled } > 10)
    }

    @Test
    fun testDexTransformerChecksumAndSha1() {
        // Construct a synthetic 512-byte DEX
        val dexBytes = ByteArray(512)
        val buf = ByteBuffer.wrap(dexBytes).order(ByteOrder.LITTLE_ENDIAN)

        // Magic dex\n035\0
        val magic = byteArrayOf(0x64, 0x65, 0x78, 0x0A, 0x30, 0x33, 0x35, 0x00)
        System.arraycopy(magic, 0, dexBytes, 0, 8)
        buf.putInt(32, 512) // file_size
        buf.putInt(36, 112) // header_size
        buf.putInt(40, 0x12345678) // endian_tag

        val transformer = DexTransformer(dexBytes)
        val (transformed, report) = transformer.transform(
            stripDebugInfo = false,
            encryptStrings = false,
            obfuscateSymbols = false,
            insertIntegritySeal = false
        )

        // Verify that Adler32 checksum in bytes[8..11] matches Adler32 of bytes[12..511]
        val adler = Adler32()
        adler.update(transformed, 12, transformed.size - 12)
        val expectedAdler = adler.value

        val resBuf = ByteBuffer.wrap(transformed).order(ByteOrder.LITTLE_ENDIAN)
        val actualAdler = resBuf.getInt(8).toLong() and 0xFFFFFFFFL

        assertEquals(expectedAdler, actualAdler)

        // Verify SHA-1 in bytes[12..31]
        val md = MessageDigest.getInstance("SHA-1")
        md.update(transformed, 32, transformed.size - 32)
        val expectedSha1 = md.digest().joinToString("") { "%02x".format(it) }

        val actualSha1Bytes = ByteArray(20)
        System.arraycopy(transformed, 12, actualSha1Bytes, 0, 20)
        val actualSha1 = actualSha1Bytes.joinToString("") { "%02x".format(it) }

        assertEquals(expectedSha1, actualSha1)
    }

    @Test
    fun testBouncyCastleCertificateGeneration() {
        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048)
        val keyPair = kpg.generateKeyPair()

        val notBefore = Date(System.currentTimeMillis() - 1000L * 60)
        val notAfter = Date(System.currentTimeMillis() + 1000L * 60 * 60 * 24 * 365)
        val serial = BigInteger.valueOf(123456789L)
        val issuer = X500Name("CN=WIBES PROTECT Test, O=Wibes Security, C=US")

        val builder = JcaX509v3CertificateBuilder(
            issuer,
            serial,
            notBefore,
            notAfter,
            issuer,
            keyPair.public
        )

        val signer = JcaContentSignerBuilder("SHA256withRSA").build(keyPair.private)
        val certHolder = builder.build(signer)
        val cert = JcaX509CertificateConverter().getCertificate(certHolder)

        assertNotNull(cert)
        assertTrue(cert.subjectX500Principal.name.contains("WIBES PROTECT Test"))
        cert.verify(keyPair.public)
    }
}
